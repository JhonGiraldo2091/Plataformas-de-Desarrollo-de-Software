package com.unir.api_sql.controller;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.unir.api_sql.model.Producto;
import com.unir.api_sql.repository.InterfaceProducto;

@RestController
@RequestMapping("/productos")
public class ProductoController {
	
	@Autowired
	private InterfaceProducto interfaceproducto;
	
	@GetMapping
	public List<Producto> productos(){
	return (List<Producto>) interfaceproducto.findAll();
	}
	@PostMapping
	public void insertar(@RequestBody Producto pe) {
		interfaceproducto.save(pe);
	}
	@PatchMapping (value="/{id}")
	public void modificar(@RequestBody Producto pe, @PathVariable("id") Integer id) {
		interfaceproducto.save(pe);
	}
	@DeleteMapping(value="/{id}")
	public void eliminar(@PathVariable("id") Integer id){
		interfaceproducto.deleteById(id);
	}
	
	

}
