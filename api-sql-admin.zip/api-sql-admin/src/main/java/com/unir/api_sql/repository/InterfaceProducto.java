package com.unir.api_sql.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.unir.api_sql.model.Producto;

@Repository
public interface InterfaceProducto extends CrudRepository<Producto, Integer>{

}
