package com.unir.api_sql.repository;

import com.unir.api_sql.model.Pedido;

public class PedidoImplementacion extends Pedido {

}
