package com.unir.api_sql.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.unir.api_sql.model.Pedido;
import com.unir.api_sql.model.Producto;
import com.unir.api_sql.repository.InterfacePedido;

@RestController
@RequestMapping("/pedidos")
public class PedidoController {

	@Autowired
	private InterfacePedido interfacePedido;
	
	@GetMapping
	public List<Pedido> pedidos(){
	return (List<Pedido>) interfacePedido.findAll();
	}
	@PostMapping
	public void insertar(@RequestBody Pedido pe) {
		interfacePedido.save(pe);
	}
	@PatchMapping (value="/{id}")
	public void modificar(@RequestBody Pedido pe, @PathVariable("id") Integer id) {
		interfacePedido.save(pe);
	}
	@DeleteMapping(value="/{id}")
	public void eliminar(@PathVariable("id") Integer id){
		interfacePedido.deleteById(id);
	}
}
