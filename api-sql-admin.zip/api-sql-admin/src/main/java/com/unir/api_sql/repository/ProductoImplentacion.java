package com.unir.api_sql.repository;

import com.unir.api_sql.model.Producto;

public class ProductoImplentacion extends Producto {

}
