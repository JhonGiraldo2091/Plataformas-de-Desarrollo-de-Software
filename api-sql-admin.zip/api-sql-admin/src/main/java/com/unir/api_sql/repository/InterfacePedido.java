package com.unir.api_sql.repository;

import org.springframework.data.repository.CrudRepository;

import com.unir.api_sql.model.Pedido;

public interface InterfacePedido extends CrudRepository<Pedido, Integer>{

}
